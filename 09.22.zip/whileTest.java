
public class whileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=0;
while(a<10)
{
	a++;
	System.out.println("a="+a);
}
	}

}
