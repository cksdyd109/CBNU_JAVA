
public class Gugudan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=2;i<10;i++)
		{
			System.out.println(i+"��");
			for(int k=1;k<10;k++){
				System.out.println(i+"x"+k+"="+i*k+"�Դϴ�.");
				
			}
				
		}
	}

}
