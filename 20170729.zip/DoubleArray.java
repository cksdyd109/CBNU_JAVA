
public class DoubleArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ar[][]= {{10,20},{30,40}};
for(int i=0;i<ar.length;i++) {
	for(int j=0;j<ar[i].length;j++)
		System.out.printf(" "+ar[i][j]);
	System.out.println();
}
	}

}
